package mapper;

import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import java.util.List;

/**
 * Created by Administrator on 2016/7/18.
 */
public interface ArticleMapper {

    @Select("SELECT * FROM t_article")
    List<Article> selectAll();
}
