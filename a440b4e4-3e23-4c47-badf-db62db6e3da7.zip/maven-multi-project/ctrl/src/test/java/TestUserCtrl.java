import ctrl.UserCtrl;
import org.junit.Assert;
import org.junit.Test;

/**
 * Created by Administrator on 2016/7/6.
 */
public class TestUserCtrl {
    @Test
    public void testUserCtrl() {
        UserCtrl userCtrl = new UserCtrl();
        Assert.assertEquals("darkfireworld", userCtrl.getUser().getName());
    }
}
