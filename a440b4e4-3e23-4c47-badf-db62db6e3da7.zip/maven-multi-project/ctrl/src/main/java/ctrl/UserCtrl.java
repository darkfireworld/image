package ctrl;

import biz.UserBiz;
import model.User;

/**
 * Created by Administrator on 2016/7/6.
 */
public class UserCtrl {
    public User getUser() {
        UserBiz userBiz = new UserBiz();
        return userBiz.getUser();
    }
}
