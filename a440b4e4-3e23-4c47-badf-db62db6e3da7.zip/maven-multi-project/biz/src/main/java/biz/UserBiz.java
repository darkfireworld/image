package biz;

import io.UserIo;
import model.User;

/**
 * Created by Administrator on 2016/7/6.
 */
public class UserBiz {
    public User getUser() {
        UserIo userIo = new UserIo();
        return userIo.select();
    }
}
