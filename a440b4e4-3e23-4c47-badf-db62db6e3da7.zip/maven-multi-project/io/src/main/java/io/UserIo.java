package io;

import model.User;

/**
 * Created by Administrator on 2016/7/6.
 */
public class UserIo {
    public User select() {
        return new User("darkfireworld");
    }
}
