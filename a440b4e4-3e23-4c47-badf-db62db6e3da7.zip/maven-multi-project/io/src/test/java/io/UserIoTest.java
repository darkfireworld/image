package io;

import org.junit.Assert;
import org.junit.Test;

/**
 * Created by Administrator on 2016/7/6.
 */
public class UserIoTest {
    @Test
    public void testUserIo() {
        UserIo userIo = new UserIo();
        Assert.assertEquals("darkfireworld", userIo.select().getName());
    }
}
