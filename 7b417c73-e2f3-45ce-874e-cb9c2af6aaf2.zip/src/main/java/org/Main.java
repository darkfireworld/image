package org;

/**
 * Created by Administrator on 2017/7/19.
 */
public class Main {
    static public void main(String[] args){
        System.out.println("HELLO WORLD");
    }
}
